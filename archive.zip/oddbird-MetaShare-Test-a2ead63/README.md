CumulusCI-Test
==============

Dummy project used to test CumulusCI - CumulusCI will run this project through the whole CI flow to verify everything works.
